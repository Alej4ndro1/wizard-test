<?php
function child_style() {
       // wp_enqueue_style( 'smartwizardcss', 'https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/smart_wizard.min.css', false, '', 'all' );
       // wp_enqueue_style( 'swarrows', 'https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/smart_wizard_theme_arrows.min.css', false, '', 'all' );
       wp_enqueue_style( 'bs', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css', false, '4.6.0', 'all' );
       wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'twenty-twenty-one-style'));


       // wp_enqueue_script( 'smartwizard', 'https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/jquery.smartWizard.min.js', '', false );
       wp_deregister_script( 'jquery' );
       wp_register_script( 'jquery', 'https://code.jquery.com/jquery-3.6.0.min.js', false, null, true );
       wp_enqueue_script( 'jquery' );
       wp_enqueue_script( 'popper', 'https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js', array('jquery'), '1.16.1', true );
       wp_enqueue_script( 'bsjs', 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js', array('popper'), '4.6.0', false );
 }
add_action( 'wp_enqueue_scripts', 'child_style' );

?>