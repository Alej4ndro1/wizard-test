<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>

<!-- <div id="main">
    <div id="bg">


      <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
      <li class="breadcrumb-item home"><a href="#"><img src="https://lh3.googleusercontent.com/fcUFaD9rdqi1SnEsXsihHpYWzP5G4wuJSVxQK7Pm2yUC_VAfe1Bp0zbHoQthpWgT0mDZG2E=s16"></a><img src="Left.png" alt=""></li>
      <li class="breadcrumb-item"><a href="#"><span class="text">Contact Info</a></li>
      <li class="breadcrumb-item active" aria-current="page"><span class="text">Quantity</li>
      <li class="breadcrumb-item active" aria-current="page"><span class="text">Price</li>
      <li class="breadcrumb-item active" aria-current="page"><span class="text">Done</span></li>
      </ol>
      </nav>

      <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#">Компоненты</a></li>
      <li class="breadcrumb-item"><a href="#">pdoTools</a></li>
      <li class="breadcrumb-item active">Парсер</li>
      </ol>
    </div>
</div> -->

<div class="container-wrapper">

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-10">
          <form class="form-steps forms-container">

            <!-- hidden inputs -->
              <input type="hidden" name="project_name" value="Test Work (Wizard)">
              <input type="hidden" name="admin_email" value="osobchuk1@gmail.com">
              <input type="hidden" name="form_subject" value="Wizard">
            <!-- hidden inputs -->

            <ul class="steps-menu">
              <!-- <li><span><img src="wp-content/themes/twentytwentyone-child/img/home.png" alt=""></span></li> -->
              <li  class="active"><span>Contact Info</span></li>
              <li><span>Quantity</span></li>
              <li><span>Price</span></li>
              <li><span>Done</span></li>
            </ul>

            <div class="form-content">

              <div class="form-content-body active">
                <h2>Contact Info</h2>
                <div class="form-group align-items-center row formpos">
                  <div class="col-sm-3">
                    <label for="inputPassword" class="col-form-label">Name</label>
                  </div>
                  <div class="col-sm-6">
                    <input type="password" class="form-control formsize" id="inputPassword" placeholder="">
                  </div>
                </div>
                <div class="form-group align-items-center row formpos">
                  <div class="col-sm-3">
                    <label for="staticEmail" class="col-form-label ">Email <sup>required</sup></label>
                  </div>
                    <div class="col-sm-6">
                      <span class="error">Empty field Email</span>
                      <input type="text" class="form-control formsize" name="email">
                    </div>
                </div>
                <div class="form-group align-items-center row formpos">
                  <div class="col-sm-3">
                    <label for="inputPassword" class="col-form-label">Phone</label>
                  </div>
                  <div class="col-sm-6">
                    <input type="password" class="form-control formsize" id="inputPassword" placeholder="">
                  </div>
                </div>

                  <div class="form-controls">
                    <button class="button cont-butt">Continue</button>
                  </div>
                </div>

                <div class="form-content-body">
                <h2>Quantity</h2>
                <div class="form-group align-items-center row formpos">
                  <div class="col-sm-3">
                    <label for="staticEmail" class="col-form-label ">Quantity <sup>required</sup></label>
                  </div>
                    <div class="col-sm-6">
                      <span class="error">Empty field Quantity</span>
                      <input type="number" class="form-control formsize" name="quant">
                    </div>
                </div>
                  <div class="form-controls">
                    <button class="button cont-butt">Continue</button>
                    <button class="button cont-butt back"><img src="wp-content/themes/twentytwentyone-child/img/Back.png" alt="" class="backimg"></button>
                  </div>
                </div>

                <div class="form-content-body">
                  <h2>Price</h2>
                  <div class="form-group align-items-center row formpos">
                    <div class="col-12">
                      <p class="price">$<span>10</span></p>
                      <input type="hidden" class="price-hidden">
                    </div>
                  </div>
                    <div class="form-controls">
                      <button class="button send-email">Send to email</button>
                      <button class="button cont-butt back"><img src="wp-content/themes/twentytwentyone-child/img/Back.png" alt="" class="backimg"></button>
                    </div>
                </div>

                <div class="form-content-body">
                  <h2>Done</h2>
                  <div class="form-group align-items-center row formpos">
                    <div class="col-12">
                      <p class="message message-done"><span>✅ Your email was send successfully</span></p>
                      <p class="message message-error"><span>⚠️ We cannot send you email right now. Use alternative way to contact us</span></p>
                    </div>
                  </div>
                    <div class="form-controls">
                      <button class="button send-again"><img src="wp-content/themes/twentytwentyone-child/img/Continue.png" alt="" class="btnstartimg"></button>
                    </div>
                </div>

            </div>

            <!-- <button class="btn continue">Continue</button>
            <button class="btn back"><img src="wp-content/themes/twentytwentyone-child/img/Back.png" alt="" class="backimg"></button>
            <button class="btn btnemail">Send to Email</button>
            <button class="btn btnstart"><img src="wp-content/themes/twentytwentyone-child/img/Continue.png" alt="" class="btnstartimg"></button> -->

        </form>
      </div>
    </div>
  </div>

</form>

<script>

   $('input[name=email]').click(function(){
      $(this).siblings('.error').removeClass('active');
    })

  $('.cont-butt').click(function(event){

    event.preventDefault();
    let formContentBody = $(this).parent().parent();
    if( formContentBody.has('input[name=email]').length > 0 ) {
      if( formContentBody.find('input[name=email]').val().length == 0 ) {
        formContentBody.find('.error').addClass('active');
        return false;
      }
      else {
        formContentBody.fadeOut();
        setTimeout(function(){
          formContentBody.removeClass('active');
          formContentBody.next().fadeIn().addClass('active');
        }, 500)
        $('.steps-menu li').removeClass('active').eq(formContentBody.index()+1).addClass('active');
      }
    } else {
       if( formContentBody.has('input[name=quant]').length > 0 ) {
         if( formContentBody.find('input[name=quant]').val().length == 0 ) {
          formContentBody.find('.error').addClass('active');
          return false;
       } else {
        if (formContentBody.find('input[name=quant]').val() > 1000) {
          formContentBody.find('input[name=quant]').val(1000);
        } else {
          if (formContentBody.find('input[name=quant]').val() >= 1 && formContentBody.find('input[name=quant]').val() <= 10) {
            $('.price span').text(10);
            $('.price-hidden').val(10);
          } else if ( formContentBody.find('input[name=quant]').val() >= 11 && formContentBody.find('input[name=quant]').val() <= 100 ) {
            $('.price span').text(100);
            $('.price-hidden').val(100);
          } else if ( formContentBody.find('input[name=quant]').val() >= 101 && formContentBody.find('input[name=quant]').val() <= 1000 ) {
            $('.price span').text(1000);
            $('.price-hidden').val(1000);
          } else {
            return false;
          }
          formContentBody.fadeOut();
          setTimeout(function(){
            formContentBody.removeClass('active');
            formContentBody.next().fadeIn().addClass('active');
          }, 500)
          $('.steps-menu li').removeClass('active').eq(formContentBody.index()+1).addClass('active');
        }
       }
     }
    }
    
  });

  $('.back').click(function(event){
    event.preventDefault();
    let formContentBody = $(this).parent().parent();
    formContentBody.fadeOut();
    setTimeout(function(){
      formContentBody.removeClass('active');
      formContentBody.prev().fadeIn().addClass('active');
    }, 500)
    $('.steps-menu li').removeClass('active').eq(formContentBody.index()-1).addClass('active'); //Что такое eq?
  })

  $('.send-email').click(function(event){
    event.preventDefault();
    let form = $('.form-steps');
    
    $.ajax({
      type: 'POST',
      url: 'mail.php',
      data: form.serialize()
    }).done(function(){
        $('.message-done').addClass('active');
        form.trigger('reset');
    }).fail(function(){
        $('.message-error').addClass('active');
        form.trigger('reset');
    });

    let formContentBody = $(this).parent().parent();
    formContentBody.fadeOut();
    setTimeout(function(){
      formContentBody.removeClass('active');
      formContentBody.next().fadeIn().addClass('active');
    }, 500)
    $('.steps-menu li').removeClass('active').eq(formContentBody.index()+1).addClass('active');

  })

  $('.send-again').click(function(event){
    event.preventDefault();
    $('.steps-menu li').removeClass('active').first().addClass('active');
    let formContentBody = $(this).parent().parent();
    formContentBody.fadeOut();
    $('.form-content .form-content-body').first().fadeIn().addClass('active');
  })


</script>